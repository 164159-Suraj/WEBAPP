package com.ct.CertificateTracker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ct.CertificateTracker.model.Admin;
import com.ct.CertificateTracker.model.CoreCertificationDetails;
import com.ct.CertificateTracker.model.Tower;
import com.ct.CertificateTracker.service.AdminService;

@RestController
@CrossOrigin("*")
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminService service;
	
	@GetMapping("/towers")
	public List<Tower> getDetails() {
		return service.getTowers();
	}
	
	
	
	@GetMapping("/getCertificates")
	public List<CoreCertificationDetails> getCertificateDetails(){
		return service.getCertificateDetails();
		
	}
	
	@PostMapping("/addCertificate")
	public CoreCertificationDetails addNewCertificate(@RequestBody CoreCertificationDetails certificate ) {
		return service.addnewCertificate(certificate);
		
	}
	
	@PostMapping("/login")
	public Admin loginValidate(@RequestBody Admin admin) {
		return service.loginValidate(admin);
		
	}
	
	@PostMapping("/register")
	public Admin register(@RequestBody Admin admin) {
		return service.register(admin);
		
		
	}

}
