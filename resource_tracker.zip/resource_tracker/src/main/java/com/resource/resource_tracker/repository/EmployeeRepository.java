package com.resource.resource_tracker.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.resource.resource_tracker.model.Employee;

public interface EmployeeRepository extends MongoRepository<Employee, Integer> {

}