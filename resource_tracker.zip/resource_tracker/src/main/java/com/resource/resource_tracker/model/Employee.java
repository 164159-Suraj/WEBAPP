/**
 * 
 */
package com.resource.resource_tracker.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author surmitra
 *
 */

@Document(collection="employee")
public class Employee {
	@Id
	 int employeeId;
	 String employeeName;
	 String localGrade;
	 String grade;
	 String mode;
	 String cloudJoiningDate;
	 String joiningDate;
	 String officeLocation;
	 String location;
	 String seat;
	 String email;
	 String benchStartDate;
	 String level3EngagementRole;
	 String gP;
	 String currentAccount;
	 String projectCode;
	 String projectName;
	 String projectStartDate;
	 String projectEndDate;
	 String primarySkill;
	 
	 public Employee(int employeeId, String employeeName){
			this.employeeId = employeeId;
			this.employeeName = employeeName;
		 
	 }
	 
	 
	 
	public Employee(int employeeId, String employeeName, String localGrade,
			String grade, String mode, String cloudJoiningDate,
			String joiningDate, String officeLocation, String location,
			String seat, String email, String benchStartDate,
			String level3EngagementRole, String gP, String currentAccount,
			String projectCode, String projectName, String projectStartDate,
			String projectEndDate, String primarySkill) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.localGrade = localGrade;
		this.grade = grade;
		this.mode = mode;
		this.cloudJoiningDate = cloudJoiningDate;
		this.joiningDate = joiningDate;
		this.officeLocation = officeLocation;
		this.location = location;
		this.seat = seat;
		this.email = email;
		this.benchStartDate = benchStartDate;
		this.level3EngagementRole = level3EngagementRole;
		this.gP = gP;
		this.currentAccount = currentAccount;
		this.projectCode = projectCode;
		this.projectName = projectName;
		this.projectStartDate = projectStartDate;
		this.projectEndDate = projectEndDate;
		this.primarySkill = primarySkill;
	}





	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}





	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}





	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}





	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}





	/**
	 * @return the localGrade
	 */
	public String getLocalGrade() {
		return localGrade;
	}





	/**
	 * @param localGrade the localGrade to set
	 */
	public void setLocalGrade(String localGrade) {
		this.localGrade = localGrade;
	}





	/**
	 * @return the grade
	 */
	public String getGrade() {
		return grade;
	}





	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}





	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}





	/**
	 * @param mode the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}





	/**
	 * @return the cloudJoiningDate
	 */
	public String getCloudJoiningDate() {
		return cloudJoiningDate;
	}





	/**
	 * @param cloudJoiningDate the cloudJoiningDate to set
	 */
	public void setCloudJoiningDate(String cloudJoiningDate) {
		this.cloudJoiningDate = cloudJoiningDate;
	}





	/**
	 * @return the joiningDate
	 */
	public String getJoiningDate() {
		return joiningDate;
	}





	/**
	 * @param joiningDate the joiningDate to set
	 */
	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}





	/**
	 * @return the officeLocation
	 */
	public String getOfficeLocation() {
		return officeLocation;
	}





	/**
	 * @param officeLocation the officeLocation to set
	 */
	public void setOfficeLocation(String officeLocation) {
		this.officeLocation = officeLocation;
	}





	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}





	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}





	/**
	 * @return the seat
	 */
	public String getSeat() {
		return seat;
	}





	/**
	 * @param seat the seat to set
	 */
	public void setSeat(String seat) {
		this.seat = seat;
	}





	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}





	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}





	/**
	 * @return the benchStartDate
	 */
	public String getBenchStartDate() {
		return benchStartDate;
	}





	/**
	 * @param benchStartDate the benchStartDate to set
	 */
	public void setBenchStartDate(String benchStartDate) {
		this.benchStartDate = benchStartDate;
	}





	/**
	 * @return the level3EngagementRole
	 */
	public String getLevel3EngagementRole() {
		return level3EngagementRole;
	}





	/**
	 * @param level3EngagementRole the level3EngagementRole to set
	 */
	public void setLevel3EngagementRole(String level3EngagementRole) {
		this.level3EngagementRole = level3EngagementRole;
	}





	/**
	 * @return the gP
	 */
	public String getgP() {
		return gP;
	}





	/**
	 * @param gP the gP to set
	 */
	public void setgP(String gP) {
		this.gP = gP;
	}





	/**
	 * @return the currentAccount
	 */
	public String getCurrentAccount() {
		return currentAccount;
	}





	/**
	 * @param currentAccount the currentAccount to set
	 */
	public void setCurrentAccount(String currentAccount) {
		this.currentAccount = currentAccount;
	}





	/**
	 * @return the projectCode
	 */
	public String getProjectCode() {
		return projectCode;
	}





	/**
	 * @param projectCode the projectCode to set
	 */
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}





	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}





	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}





	/**
	 * @return the projectStartDate
	 */
	public String getProjectStartDate() {
		return projectStartDate;
	}





	/**
	 * @param projectStartDate the projectStartDate to set
	 */
	public void setProjectStartDate(String projectStartDate) {
		this.projectStartDate = projectStartDate;
	}





	/**
	 * @return the projectEndDate
	 */
	public String getProjectEndDate() {
		return projectEndDate;
	}





	/**
	 * @param projectEndDate the projectEndDate to set
	 */
	public void setProjectEndDate(String projectEndDate) {
		this.projectEndDate = projectEndDate;
	}





	/**
	 * @return the primarySkill
	 */
	public String getPrimarySkill() {
		return primarySkill;
	}





	/**
	 * @param primarySkill the primarySkill to set
	 */
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}





	public Employee() {
		
	}
	
	
	
}

