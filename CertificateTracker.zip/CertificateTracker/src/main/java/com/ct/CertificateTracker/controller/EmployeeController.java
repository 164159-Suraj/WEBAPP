package com.ct.CertificateTracker.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ct.CertificateTracker.model.Certificate;
import com.ct.CertificateTracker.model.CoreCertificationDetails;
import com.ct.CertificateTracker.model.Employee;
import com.ct.CertificateTracker.model.PlannedCertification;
import com.ct.CertificateTracker.service.AdminService;
import com.ct.CertificateTracker.service.EmployeeService;

@RestController
@CrossOrigin("*")
@RequestMapping("/emp")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	
	
	
     
	
	/*
	 * private Integer currentUserId=185412; private String currentUser;
	 */
	
	
	@PostMapping("/update")
	public Certificate updateCertificate(@RequestBody Certificate certificate) {
		return service.updatecertificate(certificate);
	}
	
	
	@PostMapping("/add")
	public Certificate addCertificate(@RequestBody Certificate certificate) {
		return service.addCertificate(certificate);
	}
	
	
	
	@GetMapping("/view")
	public List<Certificate> getCertificates(@RequestParam("empId") Integer currentUserId){
		return service.getCertificates(currentUserId);
		
	}
	
	@GetMapping("/category")
	public Set<String> getCerCatagory(){
		return service.getCerCatigory();
		
	}
	
	
	@GetMapping("/certificates")
	public List<String> getCertificatesOfCategory(@RequestParam("category") String category){
		return service.getCertificatesOfCategory(category);
		
	}
	
	@GetMapping("/plannedCertificates")
	public List<PlannedCertification> getPlannedCertificates(@RequestParam("empId") String empId){
		return service.getPlannedCertificates(empId);
		
	}
	
	@PostMapping("/savePlannedCertificates")
	public PlannedCertification addPlannedcertifiaction(@RequestBody PlannedCertification certification){
		return service.savePlannedCertificate(certification);
	}
	
	@PostMapping("/addMarks")
	public PlannedCertification addMarks(@RequestBody PlannedCertification certification){
		//List<Integer> markList=new ArrayList<Integer>();
		
		return service.insertMarks(certification);
		
		
	}


}

