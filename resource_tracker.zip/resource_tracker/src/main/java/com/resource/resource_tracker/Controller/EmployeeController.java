package com.resource.resource_tracker.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.resource.resource_tracker.model.Employee;
import com.resource.resource_tracker.repository.EmployeeRepository;


@RestController
public class EmployeeController {
	
	
	//Employee employee=new Employee();
	
	@Autowired
	EmployeeRepository emp;
   
	@RequestMapping(method=RequestMethod.POST,value="employee/create", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void create(@RequestBody Employee employee) {
		emp.save(employee);
	}
	
	
	@RequestMapping(method=RequestMethod.GET,value="employee/present/{id}")
	public Employee isPresent(@PathVariable int id) {
		return emp.findOne(id);
	}
	
	
	
	@RequestMapping(method=RequestMethod.GET,value="employee/findall")
	public List<Employee> findall() {
		return emp.findAll();
	}
	

	@RequestMapping(method=RequestMethod.GET,value="employee/findbylocation/{location}")
	public List<Employee> findbyLocation(@PathVariable String location){
		List<Employee> list=new ArrayList<Employee>();
	List<Employee> main=emp.findAll();
	for(Employee index:main){	
		if(index.getLocation().equals(location)){
			list.add(new Employee(index.getEmployeeId(), index.getEmployeeName()));
		}
	}
        return list;
		
	
	}
	
	 @RequestMapping(value = "/employee/{id}",method = RequestMethod.DELETE) 
	 public void deleteById(@PathVariable int id) {
	       emp.delete(id); 
    }
	 
	 @RequestMapping(value = "employee/update/{id}", method = RequestMethod.PUT)
	 public void modifyPetById(@PathVariable int id, @Valid @RequestBody Employee employee) {
	   employee.setEmployeeId(id);
	   emp.save(employee);
	 }
	
	
}
