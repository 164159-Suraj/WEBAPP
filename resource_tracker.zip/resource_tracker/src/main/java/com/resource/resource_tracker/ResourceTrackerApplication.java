package com.resource.resource_tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResourceTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceTrackerApplication.class, args);
	}

}
